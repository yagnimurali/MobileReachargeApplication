package com.cg.mr.service;

import java.util.List;

import com.cg.mr.bean.CustomerDetails;
import com.cg.mr.exception.RoomBookException;

public interface IRoomBookService {
	int addCustomerDetails(CustomerDetails doctorAppointment) throws RoomBookException;
	
	CustomerDetails getBookingDetails(int appointmentId) throws RoomBookException;
	
	public List<Integer> getRoomNos() throws RoomBookException;
	
	boolean validatePatientName(String ptientname);

	boolean validatePhoneNumber(String PhoneNumber);

	boolean validateAge(String age);

	boolean validateMailId(String MailId);
	
	boolean validateGender(String gender);
	
	public int getCustId() throws RoomBookException;
	
	public String getDoctorName(String probName) throws RoomBookException;

}
