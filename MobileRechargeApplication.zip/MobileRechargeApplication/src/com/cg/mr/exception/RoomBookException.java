package com.cg.mr.exception;

public class RoomBookException extends Exception {
	public RoomBookException(String msg) {
		super(msg);
	}

}
