package com.cg.mr.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = 
	"INSERT INTO customerDetails VALUES(appoint_seq.nextval,?,?,?,?,?,?)";
	static String SEARCH_DOCTOR = "SELECT DOCTORNAME FROM PROBLEMLIST WHERE PROBLEM = ?";
	static String GET_APPOINTMENT_DETAILS = "SELECT patientName,appointmentStatus,doctorName,dateOfAppointment FROM DOCTORAPPOINTMENT where appointmentId = ?";
	static String GET_APPOINTMENT_ID = "SELECT appoint_seq.CURRVAL FROM DUAL";
	static String GET_ROOM_NO ="SELECT RoonNo FROM RoomDetail";
}







