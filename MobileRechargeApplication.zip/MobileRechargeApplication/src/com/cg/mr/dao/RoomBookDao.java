package com.cg.mr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mr.bean.CustomerDetails;
import com.cg.mr.bean.RoomsDetails;
import com.cg.mr.exception.RoomBookException;
import com.cg.mr.util.DBConnecton;

public class RoomBookDao implements IRoomBookDao {

	@Override
	public int addCustomerDetails(CustomerDetails doctorAppointment) throws RoomBookException {
		Connection conn;

		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, doctorAppointment.getCustName());
			insertStmt.setString(2, doctorAppointment.getEmail());
			insertStmt.setString(3, doctorAppointment.getCustAddress());
			
			insertStmt.setString(4, doctorAppointment.getMobileNo());
			insertStmt.setString(5, doctorAppointment.getRoomType());
			insertStmt.setInt(6, doctorAppointment.getRoomNo());

			/*
			 * System.out.println(pd.getCustomerName()); System.out.println(pd.getMailId());
			 * System.out.println(pd.getPhoneNumber());
			 * System.out.println(pd.getPurchasedate());
			 * System.out.println(pd.getMobileId());
			 */

			int result = insertStmt.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new RoomBookException("Sorry! insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {

			throw new RoomBookException(e.getMessage());
		}

		return 1;
	}

	@Override
	public CustomerDetails getBookingDetails(int appointmentId) throws RoomBookException {
		Connection con = DBConnecton.getConnection();
		int appdetail = 0;

		PreparedStatement psMobSerStmt = null;
		ResultSet resultset = null;
		CustomerDetails da = new CustomerDetails();
		try {
			psMobSerStmt = con.prepareStatement(IQueryMapper.GET_APPOINTMENT_DETAILS);
			psMobSerStmt.setInt(1, appointmentId);
			resultset = psMobSerStmt.executeQuery();
			
			while (resultset.next()) {
				
				
				da.setCustName(resultset.getString(1));
				//da.setAppointmentStatus(resultset.getString(2));
				da.setRoomNo(resultset.getInt(3));
				da.setRoomType(resultset.getString(4));
				

				

				appdetail++;
			}
			
		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new RoomBookException("Tehnical problem occured. Refer log");
		}

		if (appdetail == 0) {
			return null;
		} else {
			return da;
		}
	}

	@Override
	public List<Integer> getRoomNos() throws RoomBookException {

		Connection con = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		List<Integer> mobileIDsList = new ArrayList<Integer>();
		try {
			psMobIDStmt = con.prepareStatement(IQueryMapper.GET_ROOM_NO);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList.add(resultsetMobId.getInt(1));

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			
			throw new RoomBookException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new RoomBookException("Error in closing db connection");

			}
		}

		if (mobileIDsCount == 0)
			return null;
		else
			return mobileIDsList;
	}

	@Override
	public String getDoctorName(String probName) throws RoomBookException {
		Connection con = DBConnecton.getConnection();
		int docCount = 0;

		PreparedStatement psMobSerStmt = null;
		ResultSet resultset = null;
		String Doctor = null;

		//List<String> docList = new ArrayList<String>();
		try {
			psMobSerStmt = con.prepareStatement(IQueryMapper.SEARCH_DOCTOR);
			psMobSerStmt.setString(1, probName);
			resultset = psMobSerStmt.executeQuery();
			

			while (resultset.next()) {
				//prb.setDoctorName(resultset.getString(1));
				//docList.add(resultset.getString(1));
				 Doctor = resultset.getString(1);
				

				docCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new RoomBookException("Doctor name method Tehnical problem occured. Refer log");
		}

		if (docCount == 0) {
			return null;
		} else {
			return Doctor;
		}
	}

	@Override
	public int getCustId() throws RoomBookException {
		Connection conn;
		PreparedStatement getAppmStmt = null;
		ResultSet appointIdResult = null;
		int appointid = 0;
		try {
			conn = DBConnecton.getConnection();
			getAppmStmt = conn.prepareStatement(IQueryMapper.GET_APPOINTMENT_ID);
			appointIdResult = getAppmStmt.executeQuery();
			if (appointIdResult.next()) {
				appointid = appointIdResult.getInt(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (RoomBookException e) {
			throw new RoomBookException("Sorry purchseid not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RoomBookException("Sorry purchseid sql exception genrated");

		}

		return appointid;
	}

}
