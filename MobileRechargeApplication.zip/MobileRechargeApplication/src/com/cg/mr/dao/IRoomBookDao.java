package com.cg.mr.dao;

import java.util.List;

import com.cg.mr.bean.CustomerDetails;
import com.cg.mr.exception.RoomBookException;

public interface IRoomBookDao {
	int addCustomerDetails(CustomerDetails doctorAppointment) throws RoomBookException;
	public String getDoctorName(String probName) throws RoomBookException;
	CustomerDetails getBookingDetails(int appointmentId) throws RoomBookException;
	public List<Integer> getRoomNos() throws RoomBookException;
	public int getCustId() throws RoomBookException;

}
