package com.cg.mr.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.mr.bean.CustomerDetails;
import com.cg.mr.dao.RoomBookDao;
import com.cg.mr.dao.IRoomBookDao;
import com.cg.mr.exception.RoomBookException;

public class RoomBookService implements IRoomBookService {
	
	IRoomBookDao idocapp;

	@Override
	public int addCustomerDetails(CustomerDetails doctorAppointment) throws RoomBookException {
		idocapp = new RoomBookDao();
		int res = idocapp.addCustomerDetails(doctorAppointment);
		return res;
	}

	@Override
	public CustomerDetails getBookingDetails(int appointmentId) throws RoomBookException {
		idocapp = new RoomBookDao();
		CustomerDetails docdet = 
				idocapp.getBookingDetails(appointmentId);
		return docdet;
	}

	
	@Override
	public boolean validatePatientName(String cname) {
		String patterns = "[A-Z][a-z ]{1,20}";
		if (Pattern.matches(patterns, cname)) {
			return true;
		} else {
			return false;
		}

	}
	
	
	
	
	@Override
	public boolean validatePhoneNumber(String PhoneNumber) {
		String patterns1 = "\\d{10}";
		if (Pattern.matches(patterns1, PhoneNumber)) {
			return true;
		} else {

			return false;
		}

	}

	@Override
	public boolean validateAge(String age) {
		String patterns1 = "\\d{1,2}";
		if (Pattern.matches(patterns1, age)) {
			return true;
		} else {

			return false;
		}
	}

	@Override
	public boolean validateMailId(String MailId) {
		String patterns = "[A-Za-z0-9]{1,}[@][A-Za-z0-9.]{1,}";
		if (Pattern.matches(patterns, MailId)) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean validateGender(String gender) {
		if(gender.equalsIgnoreCase("male")||gender.equalsIgnoreCase("female")||gender.equalsIgnoreCase("other")) {
			return true;
		}
		return false;
	}

	@Override
	public List<Integer> getRoomNos() throws RoomBookException {
		idocapp = new RoomBookDao();
		List<Integer> problems = idocapp.getRoomNos();
		return problems;
	}

	@Override
	public int getCustId() throws RoomBookException {
		idocapp = new RoomBookDao();
		int appId = idocapp.getCustId();
		return appId;
	}

	@Override
	public String getDoctorName(String probName) throws RoomBookException {
		idocapp = new RoomBookDao();
		String doctor = idocapp.getDoctorName(probName);
		return doctor;
	}
	
	
	
	
}
