package com.cg.mr.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.mr.bean.CustomerDetails;
import com.cg.mr.exception.RoomBookException;
import com.cg.mr.service.RoomBookService;
import com.cg.mr.service.IRoomBookService;

public class Client {
	private static Scanner in;

	private static IRoomBookService ida = new RoomBookService();
	
	






	public static void main(String[] args) throws RoomBookException {

		in = new Scanner(System.in);
		System.out.println(" \nWelcome to mobile purchase portal\n");
		while (true) {
			System.out.println(" \nEnter your choice:\n");
			System.out.println(" 1.Book Room\n");
			System.out.println(" 2.View Booing Status\n");
			System.out.println(" 3.Exit\n");
			int choice = in.nextInt();
			switch (choice) {

			case 1:
				getInputs();
				break;

			case 2:
				System.out.println("Enter your Appointment ID");
				int ID = in.nextInt();
				//ida.getAppointmentDetails(ID);
				viewBookingStatus(ID);
				break;

			case 3:
				System.out.println("\n\nThank you");
				System.exit(0);

			}

		}

	}
	
	
	
private static void getInputs() throws RoomBookException {
		
		String CustName;
		String email;
		String CustAddress;
		String MobileNo;
		int RoomNo;
		String RoomType;
		String status;
		
		CustomerDetails da = new CustomerDetails();

		

			while (true) {
				in.nextLine();
				System.out.println("Enter Customer name");

				CustName = in.nextLine();

				if (ida.validatePatientName(CustName)) {
					break;
				} else {
					System.out.println("Invalid patient name");
				}
			}
			
			while (true) {
				System.out.println("Please enter mail id ");

				email = in.next();

				if (ida.validateMailId(email)) {
					break;
				} else {
					System.out.println("Invalid mail id");
				}
			}

			
			while (true) {
				System.out.println("Please enter CustAddress");

				CustAddress = in.next();

				if (ida.validateGender(CustAddress)) {
					break;
				} else {
					System.out.println("Invalid CustAddress");
				}
			}
			

			while (true) {
				System.out.println("Enter phone number");

				MobileNo = in.next();

				if (ida.validatePhoneNumber(MobileNo)) {
					break;
				} else {
					System.out.println("Invalid phone number");
				}
			}

			
			while (true) {
				System.out.println("Please enter RoomNo ");

				RoomNo = in.nextInt();
				String Age = Integer.toString(RoomNo);

				if (ida.validateAge(Age)) {
					break;
				} else {
					System.out.println("Invalid RoomNo");
				}
			}

			
			
				System.out.println("Enter RoomType");
				RoomType = in.next();
				RoomType = RoomType.toLowerCase();
				if (ida.getRoomNos().contains(RoomType)) {
					status = "Booked";
				} else {
					status = "Not Booked";
					
				}
			
				
				da.setCustName(CustName);
				da.setMobileNo(MobileNo);
				da.setEmail(email);
				da.setRoomNo(RoomNo);
				da.setCustAddress(CustAddress);
				da.setRoomType(RoomType);
				
				
				ida.addCustomerDetails(da);
				System.out.println("your Customer ID: "+ida.getCustId());
			
	}




private static void viewBookingStatus(int appointmentId) {
	try {
		
		CustomerDetails da = ida.getBookingDetails(appointmentId);

		
				System.out.println("Name of the customer: "+da.getCustName());
				//System.out.println("Appointmen Statust: "+ da.getAppointmentStatus());
				System.out.println("Room No: "+ da.getRoomNo());
				System.out.println("Room Type: "+ da.getRoomType());

	} catch (RoomBookException e) {

		System.out.println("Error  :" + e.getMessage());
	}

}




}
